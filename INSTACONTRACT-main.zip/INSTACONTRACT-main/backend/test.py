from scriptrun import Check,Deploy


print(Deploy("random hashing algorith", "rs"))