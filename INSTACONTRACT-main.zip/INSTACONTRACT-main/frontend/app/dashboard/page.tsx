import Dashboard from "@/components/dashboard/Dashboard";
import React from "react";

export default function page() {
  return <Dashboard />;
}
